#include"SensorNivel.h"

SensorNivel::SensorNivel(void)
{
    PIN_MAX = 13;
    PIN_MIN = 12;
    pinMode(PIN_MAX,INPUT);
    pinMode(PIN_MIN,INPUT);
}

int SensorNivel::getNivel()
{
    int nivel;

    if(digitalRead(PIN_MIN)&digitalRead(PIN_MAX))
    {
        nivel = NIVEL_MIN;
    }
    else if(!digitalRead(PIN_MIN)&digitalRead(PIN_MAX))
    {
        nivel = NIVEL_MED;
    }
    else
    {
        nivel = NIVEL_MAX;
    }

    return nivel;
}
