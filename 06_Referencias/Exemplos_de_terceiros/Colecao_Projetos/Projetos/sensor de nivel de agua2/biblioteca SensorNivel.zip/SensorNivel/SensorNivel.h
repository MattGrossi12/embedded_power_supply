#ifndef SensorNivel_h
#define SensorNivel_h

#if defined(ARDUINO) && ARDUINO >= 100
#include <Arduino.h>
#else
#include <WProgram.h>
#include <pins_arduino.h>
#endif

#define NIVEL_MAX 2
#define NIVEL_MED 1
#define NIVEL_MIN 0

class SensorNivel
{
	public:
		SensorNivel(void);
		int getNivel();
	private:
	    int PIN_MIN;
        int PIN_MAX;
};
#endif
