/*********************************
***Autor: Leonardo Dalla Porta****
***********18/04/2014*************
*************Atenção**************
***O Codigo esta livre para uso,**
*desde que seja mantida sua fonte* 
********e seu autor.**************
********Faça um bom uso***********
******Att. Equipe UsinaInfo*******
*********************************/

#include "DHT.h"
#define DHTPIN 2           // Pino onde sera conectado a saida de dados do sensor

int led = 6;
int buzzer = 7;
int TempMax = 35;
int HumiMin = 50;

#define DHTTYPE DHT11      // Define o sensor utilizado

DHT dht(DHTPIN, DHTTYPE);  //Da um nome para o Sensor

void setup()
{
  Serial.begin(9600);          //Inicializa a coneçao serial
  dht.begin();                 //Inicia a comunicaçao com o sensor
  Serial.println("Acesse:");   //Escreve uma mensagem na serial
  Serial.println("www.usinainfo.com");

  pinMode(led, OUTPUT);        //Define os pinos led e buzzer como saida
  pinMode(buzzer, OUTPUT); 
}


void loop() {

  int humidade = dht.readHumidity();       //Define uma variavel para humidade
  int temperatura = dht.readTemperature(); //Define uma variavel para Temperatura

  // Se ouver falha na leitura 
  if (isnan(temperatura) || isnan(humidade)) 
  {
    Serial.println("Erro na leitura do sensor"); //Envia uma mensagem de erro para a serial
    delay(500);       //Espera um tempo
  } 

  else //Se nao ouver erro...
  {

    Serial.print("Humidade: ");    //Escreve a humidade na serial
    Serial.print(humidade);
    Serial.print(" %\t");
    Serial.print("Temperatura: "); //Escreve a temperatura na serial 
    Serial.print(temperatura);
    Serial.println(" *C");

    if(temperatura>TempMax)  //Condiçao: Se a temperatura for maior que TempMax...
    {
      digitalWrite(led, HIGH);    // Liga o Led
      digitalWrite(buzzer, HIGH); //Dá um "Bip" no buzzer
      delay(500);
      digitalWrite(buzzer, LOW);
      delay(10000);               //Aguarda 10 Segundos
      digitalWrite(led, LOW);     //Desliga o led
    }    // Fecha o loop if
    
     if(humidade<HumiMin)  //Condiçao: Se a humidade for menor que HumiMin...
    {
      digitalWrite(led, HIGH);    // Liga o Led
      
      for(int buz=0; buz<=3; buz++)  //Dá 3 "Bips" no buzzer
      {
      digitalWrite(buzzer, HIGH);
      delay(500);
      digitalWrite(buzzer, LOW);
      delay(500);
      }
      
      delay(5000);               //Aguarda 5 Segundos
      digitalWrite(led, LOW);     //Desliga o led
    }    // Fecha o loop if
    
    
    
  }      // Fecha o loop else
}        // Fecha o loop 

