#ifndef DHT_H
#define DHT_H
#if ARDUINO >= 100
 #include "Arduino.h"
#else
 #include "WProgram.h"
#endif

/* Biblioteca DHT 

Licen�a MIT
Escrito por Adafruit Industries
Adaptado por Equipe Usinainfo

*/

// Quantas transi��es de tempo precisamos para manter o controle. ( 2 * numero de bits + extra )
#define MAXTIMINGS 85

#define DHT11 11
#define DHT22 22
#define DHT21 21
#define AM2301 21

class DHT {
 private:
  uint8_t dado[6];
  uint8_t _pin, _tipo, _cont;
  boolean ler(void);
  unsigned long _ultima_leitura;
  boolean primeira_leitura;

 public:
  DHT(uint8_t pin, uint8_t tipo, uint8_t cont=6);
  void comeco(void);
  float ler_Temperatura(bool S=false);
  float converteCtoF(float);
  float le_umidade(void);

};
#endif
