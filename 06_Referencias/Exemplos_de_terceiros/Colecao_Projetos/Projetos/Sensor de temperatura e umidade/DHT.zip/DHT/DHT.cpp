/* 

Biblioteca DHT 

Licen�a MIT 
Escrito por  Adafruit Industries
Adaptado por Equipe Usinainfo

*/

#include "DHT.h"

DHT::DHT(uint8_t pin, uint8_t tipo, uint8_t cont) {
  _pin = pin;
  _tipo = tipo;
  _cont = cont;
  primeira_leitura = true;
}

void DHT::comeco(void) {
  // Configura os pinos!
  pinMode(_pin, INPUT);
  digitalWrite(_pin, HIGH);
  _ultima_leitura = 0;
}

//boolean S == Scale.  True == Farenheit; False == Celcius
float DHT::ler_Temperatura(bool S) {
  float f;

  if (ler()) {
    switch (_tipo) {
    case DHT11:
      f = dado[2];
      if(S)
      	f = converteCtoF(f);
      	
      return f;
    case DHT22:
    case DHT21:
      f = dado[2] & 0x7F;
      f *= 256;
      f += dado[3];
      f /= 10;
      if (dado[2] & 0x80)
	f *= -1;
      if(S)
	f = converteCtoF(f);

      return f;
    }
  }
  Serial.print("Leitura Falhou");
  return NAN;
}

float DHT::converteCtoF(float c) {
	return c * 9 / 5 + 32;
}

float DHT::le_umidade(void) {
  float f;
  if (ler()) {
    switch (_tipo) {
    case DHT11:
      f = dado[0];
      return f;
    case DHT22:
    case DHT21:
      f = dado[0];
      f *= 256;
      f += dado[1];
      f /= 10;
      return f;
    }
  }
  Serial.print("Leitura Falhou");
  return NAN;
}


boolean DHT::ler(void) {
  uint8_t ultimo_estado = HIGH;
  uint8_t counter = 0;
  uint8_t j = 0, i;
  unsigned long tempo_atual;

  // Puxa o pino HIGH e espera 250 milissegundos
  digitalWrite(_pin, HIGH);
  delay(250);

  tempo_atual = millis();
  if (tempo_atual < _ultima_leitura) {
    // houve um erro
    _ultima_leitura = 0;
  }
  if (!primeira_leitura && ((tempo_atual - _ultima_leitura) < 2000)) {
    return true; // Retorna ultima medi��o correta
    //delay(2000 - (tempo_atual - _ultima_leitura));
  }
  primeira_leitura = false;
  /*
    Serial.print("Tempo Atual: "); Serial.print(tempo_atual);
    Serial.print(" Ultimo tempo lido: "); Serial.print(_ultima_leitura);
  */
  _ultima_leitura = millis();

  dado[0] = dado[1] = dado[2] = dado[3] = dado[4] = 0;
  
  // Agora seta Low por 20 Milissegundos
  pinMode(_pin, OUTPUT);
  digitalWrite(_pin, LOW);
  delay(20);
  cli();
  digitalWrite(_pin, HIGH);
  delayMicroseconds(40);
  pinMode(_pin, INPUT);

  // Ler os tempos
  for ( i=0; i< MAXTIMINGS; i++) {
    counter = 0;
    while (digitalRead(_pin) == ultimo_estado) {
      counter++;
      delayMicroseconds(1);
      if (counter == 255) {
        break;
      }
    }
    ultimo_estado = digitalRead(_pin);

    if (counter == 255) break;

    // Ignora as primeiras 3 transi��es
    if ((i >= 4) && (i%2 == 0)) {
      // Seta cada bit nos bytes de armazenamento
      dado[j/8] <<= 1;
      if (counter > _cont)
        dado[j/8] |= 1;
      j++;
    }

  }

  sei();
  
  /*
  Serial.println(j, DEC);
  Serial.print(dado[0], HEX); Serial.print(", ");
  Serial.print(dado[1], HEX); Serial.print(", ");
  Serial.print(dado[2], HEX); Serial.print(", ");
  Serial.print(dado[3], HEX); Serial.print(", ");
  Serial.print(dado[4], HEX); Serial.print(" =? ");
  Serial.println(dado[0] + dado[1] + dado[2] + dado[3], HEX);
  */

  // Checa se leu 40 bits e faz a verifica��o das somas
  if ((j >= 40) && 
      (dado[4] == ((dado[0] + dado[1] + dado[2] + dado[3]) & 0xFF)) ) {
    return true;
  }
  

  return false;

}
