// Exemplo de teste dos sensores de temperatura e umidade
// Escrito por ladyada 
// Adaptado por Equipe Usinainfo

#include "DHT.h"

#define DHTPIN 11     // O pino que estive conectado...

#define DHTTYPE DHT11   // DHT 11 
//#define DHTTYPE DHT22   // DHT 22  (AM2302)
//#define DHTTYPE DHT21   // DHT 21 (AM2301)

// Conecta pin 1 (na esquerda) no sensor +5V
// Conecta pin 2 no sensor para qualquer que seja o DHTPIN 
// Conecta pin 4 (na direita) no sensor - para TERRA
// Conecta uma resistencia de 10K no pino 2 (dado) ao pino 1 (alimentação) do sensor

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600); 
  Serial.println("DHTxx test!");
 
  dht.comeco();
}

void loop() {
  // Ler temperatura ou umidade leva cerca de 250 milissegundos
  // As leituras do sensor tambem podem ser 'velhas' (Se o sensor for muito lento)
  float h = dht.le_umidade();
  float t = dht.ler_Temperatura();

  // Verifica se os retornos são validos, Se forem NAN (not a number - não um numero) então algo deu errado!
  if (isnan(t) || isnan(h)) {
    Serial.println("Falha ao ler de DHT");
  } else {
    Serial.print("Umidade: "); 
    Serial.print(h);
    Serial.print(" %\t");
    Serial.print("Temperatura: "); 
    Serial.print(t);
    Serial.println(" *C");
  }
}

