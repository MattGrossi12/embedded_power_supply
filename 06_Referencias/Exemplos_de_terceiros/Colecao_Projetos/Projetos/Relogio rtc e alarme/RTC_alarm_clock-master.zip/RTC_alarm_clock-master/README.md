# RTC_alarm_clock
Arduino RTC Alarm Clock

***********************USE Arduino IDE 1.6.6**************************

* Arduino alarm clock with DS3231 and IC2 16x2 LCD  
 * FEATURES:
 * Display Time 24h format
 * Display Date in dd/mm/yyyy format
 * Display Day of Week - auto generated DoW
 * Display Temperature (DS3231 function)
 * Menu based navigation system
 * DS3231 - Alarm1  
 * Save information of Alarm in EEPROM
 * Debounce buttons 
